The graph folder contains the graphs of this project.
The tensorboard folder contains the files used for showing on TensorBoard utils.

NeuralNetwork_pyTorch file is the file we used for running the neural network. Since the state.pt file which stores
the states of model is too large to upload to the canvas, we does not include it in submission. If you need it, you can
download through our github repository: https://github.com/lichenhao608/Optimization_Project

Optimization_Comparison file is the file we used for comparing the computational time of each optimization method with Lookahead

simple file is the file we used for tracking the convergence of each optimization method with 2000 steps.